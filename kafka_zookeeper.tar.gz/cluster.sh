#!/usr/bin/expect -f

source [file join [file dirname [info script]] cluster.env]

set whatToRun [lindex $argv 0]
set KAFKA_PROGRAM_NAME "KafkaServer"

proc startKafka {host password cmdSleepSeconds} {

  set out [concat "Processing Kafka server: " $host]
  set timeout $::methodTimeout

  puts $out

  spawn ssh $host
  expect {
    timeout {
      set out [concat $host ": Timed out. Exiting"]
      puts $out
      return false
    }
    ##login part
    "yes/no" {
      send $::yes
      exp_continue
    }
    "?assword:" {
      send $password
      exp_continue
    }
    "Last login:" {
      ## logged in, run status command
      set out [concat $host ": Logged in. Executing command:" ]
      puts $out
      send $::cmdKafkaStatus
      exp_continue
    }
    concat $::KAFKA_PROGRAM_NAME " is running" {
      set out [concat $host ": RUNNING"]
      puts $out
      return true
    }
    concat $::KAFKA_PROGRAM_NAME " is already running" {
      set out [concat $host ": ALREADY RUNNING"]
      puts $out
      return true
    }
    concat "Starting " $::KAFKA_PROGRAM_NAME {
      set out [concat $host ": Kafka server is starting. Executing command:" ]
      puts $out
      send $::cmdKafkaStatus
      exp_continue
    }
    concat $::KAFKA_PROGRAM_NAME " is not running" {
      set out [concat $host ": is stopped. Executing command:" ]
      puts $out
      send $::cmdKafkaStart
      sleep $cmdSleepSeconds
      exp_continue
    }
  }
}
proc stopKafka {host  password cmdSleepSeconds} {

  set out [concat "Processing: " $host]

  set timeout $::methodTimeout

  puts $out

  spawn ssh $host
  expect {
    timeout {
      set out [concat $host ": Timed out. Exiting"]
      puts $out
      return false
    }
    "yes/no" {
      send $::yes
      exp_continue
    }
    "?assword:" {
      send $password
      exp_continue
    }
    "Last login:" {
      set out [concat $host ": Logged in. Executing command:" ]
      puts $out
      send $::cmdKafkaStatus
      exp_continue
    }
    concat $::KAFKA_PROGRAM_NAME " is running" {
      set out [concat $host ": Kafka is running. Executing command:" ]
      puts $out
      send $::cmdKafkaStop
      sleep $cmdSleepSeconds
      exp_continue
    }

    concat "Stopping " $::KAFKA_PROGRAM_NAME {
      set out [concat $host ": Kafka is stopping. Executing command:" ]
      puts $out
      send $::cmdKafkaStatus
      exp_continue
    }

    concat $::KAFKA_PROGRAM_NAME " is not running" {
      set out [concat $host ": STOPPED"]
      puts $out
      return true
    }
  }
}

proc statusKafka {host password} {

  set out [concat "Processing: " $host]
  set timeout $::methodTimeout

  puts $out

  spawn ssh $host
  expect {
    timeout {
      set out [concat $host ": Timed out. Exiting"]
      puts $out
      return false
    }
    "yes/no" {
      send $::yes
      exp_continue
    }
    "?assword:" {
      send $password
      exp_continue
    }
    "Last login:" {
      set out [concat $host ": Logged in. Executing command:" ]
      puts $out
      send $::cmdKafkaStatus
      exp_continue
    }
    concat $::KAFKA_PROGRAM_NAME " is running" {
      set out [concat $host ": RUNNING"]
      puts $out
    }
    concat $::KAFKA_PROGRAM_NAME " is not running" {
      set out [concat $host ": STOPPED"]
      puts $out
    }
  }
}

proc statusZookeeper {host password} {

  set out [concat "Processing: " $host]
  set timeout $::methodTimeout

  puts $out

  spawn ssh $host
  expect {
    timeout {
      set out [concat $host ": Timed out. Exiting"]
      puts $out
      return false
    }
    "yes/no" {
      send $::yes
      exp_continue
    }
    "?assword:" {
      send $password
      exp_continue
    }
    "Last login:" {
      set out [concat $host ": Logged in. Executing command:" ]
      puts $out
      send $::cmdZkStatus
      exp_continue
    }
    "Mode:" {
      set out [concat $host ": RUNNING"]
      puts $out
    }
    "Error contacting service. It is probably not running." {
      set out [concat $host ": STOPPED"]
      puts $out
    }
  }
}

proc stopZookeeper {host  password cmdSleepSeconds} {

  set out [concat "Processing: " $host]
  set timeout $::methodTimeout

  puts $out

  spawn ssh $host
  expect {
    timeout {
      set out [concat $host ": Timed out. Exiting"]
      puts $out
      return false
    }
    "yes/no" {
      send $::yes
      exp_continue
    }
    "?assword:" {
      send $password
      exp_continue
    }
    "Last login:" {
      set out [concat $host ": Logged in. Executing command:" ]
      puts $out
      send $::cmdZkStatus
      exp_continue
    }
    "Mode:" {
      set out [concat $host ": Zookeeper is running. Executing command:" ]
      puts $out
      send $::cmdZkStop
      sleep $cmdSleepSeconds
      exp_continue
    }
    "Stopping zookeeper*" {
      set out [concat $host ": Zookeeper is stopping. Executing command:" ]
      puts $out
      send $::cmdZkStatus
      exp_continue
    }
    "Error contacting service. It is probably not running." {
      set out [concat $host ": STOPPED"]
      puts $out
      return true
    }
  }
}

proc startZookeeper {host password cmdSleepSeconds}  {

  set out [concat "Processing ZooKeeper server: " $host]
  set timeout $::methodTimeout

  puts $out

  spawn ssh $host
  expect {
    timeout {
      set out [concat $host ": Timed out. Exiting"]
      puts $out
      return false
    }
    "yes/no" {
      send $::yes
      exp_continue
    }
    "?assword:" {
      send $password
      exp_continue
    }
    "Last login:" {
      set out [concat $host ": Logged in. Executing command:" ]
      puts $out
      send $::cmdZkStatus
      exp_continue
    }
    "Mode:" {
      set out [concat $host ": RUNNING"]
      puts $out
      return true
    }
    "already running as process" {
      set out [concat $host ": ALREADY RUNNING"]
      puts $out
      return true
    }
    "Starting zookeeper*" {
      set out [concat $host ": Zookeeper is starting. Executing command:" ]
      puts $out
      send $::cmdZkStatus
      exp_continue
    }
    "Error contacting service. It is probably not running." {
      set out [concat $host ": is not running. Executing command:" ]
      puts $out
      send $::cmdZkStart
      sleep $cmdSleepSeconds
      exp_continue
    }
  }
}
proc cleanData {host  password cmdClean secondsWait} {

  set out [concat "Processing: " $host]
  set timeout $::methodTimeout

  puts $out

  spawn ssh $host
  expect {
    timeout {
      set out [concat $host ": Timed out. Exiting"]
      puts $out
      return false
    }
    "yes/no" {
      send $::yes
      exp_continue
    }
    "?assword:" {
      send $password
      exp_continue
    }
    "Last login:" {
      set out [concat $host ": Logged in"]
      puts $out
      set out [concat $host ": Executing command:" $cmdClean]
      puts $out
      send $cmdClean
      sleep $secondsWait
    }
  }
}

proc startAll {zookeeperHosts kafkaHosts} {
  foreach zookeeperHost $zookeeperHosts {
    puts $::SEP
    set zookeeperStarted [ startZookeeper $zookeeperHost $::zookeeperPwd 1]
    puts $::SEP
  }

  if { $zookeeperStarted == true } {
    puts "ALL ZOOKEEPER SERVERS ARE STARTED"
    foreach kafkaHost $kafkaHosts {
      puts $::SEP
      set kafkaStarted [ startKafka $kafkaHost $::kafkaPwd 1]
      puts $::SEP
    }
    if { $kafkaStarted == true } {
      puts "ALL KAFKA SERVERS ARE STARTED"
      return true
    } else {
      puts "SOME KAFKA SERVERS COULD NOT BE STARTED"
    }

  } else {
    puts "SOME ZOOKEEPER SERVERS COULD NOT BE STARTED"
  }

  return false
}
 
proc stopAll {zookeeperHosts kafkaHosts } {
  foreach kafkaHost $kafkaHosts {
    puts $::SEP
    set kafkaStopped [ stopKafka $kafkaHost $::kafkaPwd 10]
    puts $::SEP
  }

  if { $kafkaStopped == true } {
    puts "ALL KAFKA SERVERS ARE STOPPED"
    foreach zookeeperHost $zookeeperHosts {
      puts $::SEP
      set zookeeperStopped [ stopZookeeper $zookeeperHost $::zookeeperPwd 10]
      puts $::SEP
    }

    if { $zookeeperStopped == true } {
      puts "ALL ZOOKEEPER SERVERS ARE STOPPED"
      return true
    } else {
     puts "SOME ZOOKEEPER SERVERS COULD NOT BE STOPPED"
    }
  } else {
    puts "SOME KAFKA SERVERS COULD NOT BE STOPPED"
  }

  return false

}

proc statusAll {zookeeperHosts kafkaHosts} {
 foreach kafkaHost $kafkaHosts {
   puts $::SEP
   statusKafka $kafkaHost $::kafkaPwd
   puts $::SEP
  }
  foreach zookeeperHost $zookeeperHosts {
    puts $::SEP
    statusZookeeper $zookeeperHost $::zookeeperPwd
    puts $::SEP
  }
}

proc cleanAll {zookeeperHosts kafkaHosts} {

    set allStopped [stopAll $zookeeperHosts $kafkaHosts]
    if { $allStopped == true } {
      foreach kafkaHost $kafkaHosts {
        puts $::SEP
        cleanData $kafkaHost $::kafkaPwd $::cmdKafkaClean 10
        puts $::SEP
      }
      foreach zookeeperHost $zookeeperHosts {
        puts $::SEP
        cleanData $zookeeperHost $::zookeeperPwd $::cmdZkClean 10
        puts $::SEP
      }
    } else {
      puts "COULD NOT STOP ALL SERVERS"
    }

}

if { $whatToRun == "start" } {

  startAll $zookeeperHosts $kafkaHosts 

} elseif { $whatToRun == "stop" } {

  stopAll $zookeeperHosts $kafkaHosts

} elseif { $whatToRun == "status" } {

  statusAll $zookeeperHosts $kafkaHosts

} elseif { $whatToRun == "cleanData" } {

  cleanAll $zookeeperHosts $kafkaHosts

} else {

  puts "Unknown comman. Supported: start / stop / status / cleanData"

}

