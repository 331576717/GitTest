#!/usr/bin/expect -f

#
# map of tables to operate on
#
array set Tables { t1 keyspace1_sh.ems_md_esp_var01 t2 keyspace1_sh.mbr_main_messages t3 keyspace1_sh.rfq_raw_messages_var01}

#
#data directory locatioon
#
set dataDir "/home"

#
#commit logs directory base name
#
set commLogDirBase "casscomm"
#
#data directory base name
#
set dataDirBase "cassdat"

#
# cassandra user password
#
set password  "cassandra1\r"
#
#timeout of extect.method calls
#
set timeout 5000

#
##Global map of  NodeId->IP
#Re-initialized in every statusc call
#
global nodes
#
#set to to empty on startup
#
array set nodes {}

#
#command-line arguments
#
set whatToRun [lindex $argv 0]

#
# run startc cassandra service
#
proc startc {} { 
    set allUp  true
    spawn service cassandra startc
    expect {
      timeout {
          puts "Timed Out"
          return false
      }
      "?assword" {
          send $::password
          exp_continue
      }
      "/*( node*->UP" {
          puts "HAVE NODE UP"
          exp_continue
      } 
      "/*( node*->DOWN" {
          puts "HAVE NODE DOWN"
          set $allUp false
          exp_continue
      }
      "We are ***DONE***" {
          sleep 1
          return $allUp
      } else {
          continue
      }
    }
}

#
# run stopc cassandra service
#
proc stopc {} {
    set allDown  true
    spawn service cassandra stopc
    expect {
      timeout {
          puts "Timed Out"
          return false
      }
      "?assword" {
          send $::password
          exp_continue
      }
      "We are ***DONE***" {
          sleep 1
          return $allDown
      } else {
          continue
      }
    }
}

#
# run statusc cassandra service
# populate Tables with nodeId->NodeIP on each run
#
proc statusc {} {

    set allUp  true
    #re-set global array on every status run
    upvar nodes TheNodes
    array unset TheNodes

    spawn service cassandra statusc
    expect {
      timeout {
          puts "Timed Out"
          return false
      }
      "?assword" {
          puts "Sending password"
          send $::password
          exp_continue
      }
      "Going to check the node" {
        set statusReport $expect_out(buffer)
        foreach line $statusReport {
          if { [regexp {[0-9]{1,}\(([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})\)$} $line] } {
            set values [split $line "("]
            set nodeId "-"
            set ip "-"
            foreach value $values {
               if { [string  match {-} $nodeId] } {
                  puts [concat $nodeId $value]
                  set nodeId $value
               } else {
                 if { [string match {-} $ip] } {
                    set ip [regsub {\)} $value ""]
                 }
               }
            }
            set TheNodes($nodeId) $ip
          }
        }
        exp_continue
      }
      "status report row " {
        set statusReport $expect_out(buffer)
        foreach line $statusReport {
          if { [regexp {[0-9]{1,}\(([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})\)$} $line] } {
            set values [split $line "("]
            set nodeId "-"
            set ip "-"
            foreach value $values {
               if { [string  match {-} $nodeId] } {
                  puts [concat $nodeId $value]
                  set nodeId $value
               } else {
                 if { [string match {-} $ip] } {
                    set ip [regsub {\)} $value ""]
                 }
               }
            }
            set TheNodes($nodeId) $ip
          }
        }
        exp_continue
      }
      "SimpleStates:DOWN" {
          set allUp false
          exp_continue
      }
      "Node process is down" {
          set allUp false
          exp_continue
      }
      "We are ***DONE***" {
          sleep 1
          return $allUp
      } else {
          continue
      }
    }
}

#
# run "truncate table ...;" command for each entry in Tables map via cqlsh console
#
proc cleanDatac {} {
   set isConnected false
   set success true

   set connectTo "-"
   foreach {key value} [array get ::nodes] {
     set connectTo $value
   }

   spawn /export/home/cassandra/cluster/1/bin/cqlsh $connectTo
   expect {
      timeout {
          puts "Timed Out"
          return false
      }
      "Connected to * at *" {
          set isConnected true
          set cmdCleanData [buildCmdCleanData]
          send $cmdCleanData\r
          sleep 1
          exp_continue
      }
      "*Cannot achieve consistency level" {
         set success false
         puts "Looks like some of the instances in cluster are down. Please, bring them up and try again"
         exp_continue
      }
      "InvalidRequest" {
         set success false
         exp_continue
      } else {
          continue
      }

      "cqlsh>" {
         if { $isConnected == true } {
            send "exit\r"
            sleep 1
            return $success
         } else {
           exp_continue
         }

      }
    }
}

#
# builds command string truncate table <table1>; truncate table <table2>; etc
#
proc buildCmdCleanData {} {
   set cmd ""
   set cmdBase "truncate table"
   foreach {key value} [array get ::Tables] {
     set cmd [concat [concat $cmd[concat $cmdBase $value]]\;]
   }
   return $cmd 
}


#
# run delete files from data directory for each node
# run delete files from commit log directory for each node
#
proc deleteDatac {} {
   set success false
    
   foreach {key value} [array get ::nodes] {

     set cmdComm [concat [concat [concat [concat $::dataDir/]$::commLogDirBase]*]$key]
     set cmdData [concat [concat [concat $::dataDir/]$::dataDirBase]$key]

     foreach f [glob -nocomplain [file join $cmdComm *] ] {
       file delete -force $f
     }
     foreach f [glob -nocomplain [file join $cmdData *] ] {
       file delete -force $f
     }

     set success true
   }

   return $success
}

#########
# 
# main body
# 
#########

# figure out target to tun
if { $whatToRun == "start" } {
  set allUp [startc]
  if { $allUp == true } {
    puts "Cluster is UP."
  } else {
    puts "At least some nodes in the cluster are DOWN."
  }
} elseif { $whatToRun == "stop" } {

  set allDown [stopc]
  if { $allDown == true } {
    puts "Cluster is DOWN."
  } else {
    puts "At least some of the nodes are still UP."
  }

} elseif { $whatToRun == "status" } {

  set allUp [statusc]
  if { $allUp == true } {
     puts "Cluster is UP."
  } else {
    puts "At least some of the nodes in cluster are DOWN."
  }

} elseif { $whatToRun == "cleanData" } {

  set allUp [statusc]
  set cleaned false

  if { $allUp == true } {
     puts "Cluster is UP. Proceeding with data cleanup"
     set cleaned [cleanDatac]
  } else {
    puts "At least some of the nodes in cluster are DOWN\nWill try to bring cluster UP."
    set allUp [startc]
    if { $allUp == true }  {
      set cleaned [cleanDatac]
    } else {
      puts "At least some of the nodes in cluster are still DOWN.\ncleanData aborted."
    }

  }

  if { $cleaned == true } {
     puts "Done cleanData."
  } else {
    puts "cleanData failed."
  }

} elseif { $whatToRun == "deleteData" } { 

  set isUp [statusc]
  set allStopped [stopc]
  set deleted false

  if { $allStopped == true } {
     puts "Cluster is DOWN. Proceeding with data deletion"
     set deleted [deleteDatac]
  } else {
    puts "At least some of the nodes in cluster are UP.\nWill try to bring cluster down."
    set allStopped [stopc]
    if { $allStopped == true }  {
      set deleted [deleteDatac]
    } else {
      puts "At least some of the nodes in cluster are still UP.\ndeletData aborted."
    }
  }

  if { $deleted == true } {
     puts "Done deleteData."
  } else {
    puts "deleteData failed."
  }
} else {

  puts "Unknown comman. Supported: start / stop / status / cleanData / deleteData"

}


